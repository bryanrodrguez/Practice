<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis bitacoras</title>
    <link rel="icon" href="favicon/bitacora.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/tabla.css">
</head>
<body>
    <?php
    session_start();
    $config = include 'config.php';
    $mail = $_SESSION['Usuarios']['mail'];
    $nombre = $_SESSION['Usuarios']['user'] .' '. $_SESSION['Usuarios']['apellido'];
?>
<form method="POST" enctype="multipart/form-data">
                <div class="bitacora">
                    <p>Ingrese el dia de su bitacora <input type="date" name="fecha" value="<?php echo date("Y-m-d");?>" max="<?php echo date("Y-m-d")?>" ></p> 
                </div>
                <div class="cuadro-texto">
                    <textarea style="resize: none;" name="textobitacora" class="text" placeholder="Este día configure un proyecto..."></textarea>
                    <br>
                    <button name="enviar" onclick="sb()" class="button-35" style="float:right; margin-top:25px; margin-left:25px; height:53px">Enviar</button>
                    <br>
                    <input name="fichero" type="file" class="button-35"style="float:right; margin-top:25px; margin-left:25px;">
                    <div id = "comprararchivo" ><p style="color: white;"></p></div>
                    <script type="text/javascript" src="java/funciones.js"></script>
                </div>
            </form>