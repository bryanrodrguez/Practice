<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/cerrar.css">
    <title>Practice-Alumno</title>
    <link rel="icon" href="favicon/empleados.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <nav style="margin-top: 35px;">
        <a href="https://facultades.unab.cl/ingenieria/">
        <div class="bloque">
            <IMG class="Imagen" SRC="favicon/unab.png" width="150" height="60" >
        </div>
        </a>
        <a href="https://www.facebook.com/unab.cl">
            <div class="bloque">
            <IMG class="Imagen" SRC="favicon/facebook.png" width="40" height="30" >
        </div>
        </a>
        <a href="https://twitter.com/uandresbello">
            <div class="bloque">
            <IMG class="Imagen" SRC="favicon/Twitter.png" width="40" height="30" >
        </div>
        </a>
 
            

    </nav>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<br>
<br>
<br>
<body style="margin: 40px; background-color: black;">
    <div class="-body">
        <div class="botones-izquierda">
            <div class="Titulo-menu"> 
                <h1>MENU</h1>
            </div>
            <div class="cuadroboton"> 
            <button type="button" class="button-35" onclick="window.open('EJEMS/Reglamento.pdf');window.location.href = 'alumno.php'">Reglamento<br>Practica Profesional </button>
            </div>
            <div class="cuadroboton">
            <button type="button" class="button-35" onclick="window.open('EJEMS/Ejemplo.pdf');window.location.href = 'alumno.php'">Formato <br> informe</button>
            </div>
            <div class="cuadroboton"> 
            <button type="button" class="button-35" onclick="location.href='misbitacoras.php'">Mis <br> bitacoras</button>
            </div>
            <div class="cuadroboton"> 
            <button type="button" class="button-35" onclick="location.href='finalpractica.php'">Finalizar <br> Practica Profesional</button>
            </div>
        </div>       
        <?php
        $config = include 'config.php';
        $dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'];
		$conexion = new PDO($dsn,$config['db']['user'],$config['db']['pass'],$config['db']['option']);
        session_start();
        date_default_timezone_set("America/Santiago");
        if (isset($_SESSION['Usuarios']['mail'])){ //bienvenida al usuario logueado
            $usuario = $_SESSION['Usuarios']['user'];
            $rol = $_SESSION['Usuarios']['rol'];
            $mail = $_SESSION['Usuarios']['mail'];
            if ($rol == '1'){
                header('location: index.php');
            }
            if ($rol == '2'){
                $rolito = "Usuario";
            }
        }else{
            header('location: session.php');
        }
        if (isset($_POST['cerrar'])){ //Cerrar sesión
            session_destroy();
            header('location: session.php');
        }
        if (isset($_POST['enviar'])){
            if(is_uploaded_file($_FILES['fichero']['tmp_name'])){
                if(file_exists("upload/".$mail) == false){
                    mkdir("upload/".$mail);
                
                }else{
                    $flag = true;                    
                }
                if(file_exists("upload/".$mail."/".$_POST['fecha']) == false){
                    mkdir("upload/".$mail."/".$_POST['fecha']);
                }
                $filetxt = fopen("upload/".$mail."/".$_POST['fecha']."/bitacora.txt" , "w");
                $txt = $_POST['textobitacora'];
                fwrite($filetxt,$txt);
                fclose($filetxt);
                $ruta = "upload/".$mail."/".$_POST['fecha']."/".$_FILES['fichero']['name'];
                $nombre = $_FILES['fichero']['name'];
                $size = $_FILES['fichero']['size'];
                $fecha  = $_POST['fecha'];
                $bitacora = $_POST['textobitacora'];

                if (move_uploaded_file($_FILES['fichero']['tmp_name'], $ruta)){
                    $query = "INSERT INTO archivos (mail,nombre,bitacora,fecha,ruta,size) VALUES ('$mail','$nombre','$bitacora','$fecha' ,'$ruta',$size)";
                    $sentencia = $conexion->prepare($query);
		            $sentencia->execute();
                    header('location:alumno.php');
                }
                
            }
        }

        ?>
        <div class="contenido">
            <form method="POST">
                <div class="cerrar_session">
                    <button name="cerrar" class="button-35" >Cerrar Sesión</button>
                </div>
            </form>
            
            <div class="Titulo">
                <p>Bienvenido/a <?php echo $usuario; ?></p>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="bitacora">
                    <p>Ingrese el dia de su bitacora <input type="date" name="fecha" value="<?php echo date("Y-m-d");?>" max="<?php echo date("Y-m-d")?>" ></p> 
                </div>
                <div class="cuadro-texto">
                    <textarea style="resize: none;" name="textobitacora" class="text" placeholder="Este día configure un proyecto..."></textarea>
                    <br>
                    <button name="enviar" onclick="sb()" class="button-35" style="float:right; margin-top:25px; margin-left:25px; height:53px">Enviar</button>
                    <br>
                    <input name="fichero" type="file" class="button-35"style="float:right; margin-top:25px; margin-left:25px;">
                    <div id = "comprararchivo" ><p style="color: white;"></p></div>
                    <script type="text/javascript" src="java/funciones.js"></script>
                </div>
            </form>
        </div>
    </div>
</body>
</html>


