function sb(){
    document.getElementById('comprararchivo').innerHTML= "archivo subido" ;
}