<?php

return [
	'db' => [
		'host' =>'localhost',
		'user' =>'root',
		'pass' =>'',
		'name' =>'usuarios',
		'option' => [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
	]
];