<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

	<title>Registro</title>
</head>
<body>
	
</body>
</html>
<?php 
if (isset($_POST['submit'])){
	$resultado =[
		'error' =>false,
		'mensaje'=>'Usuario creado con exito'
	];
	$config = include 'config.php';
	try {
		$dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'];
		$conexion = new PDO($dsn,$config['db']['user'],$config['db']['pass'],$config['db']['option']);
		$user = [
			"usuario" => $_POST['usuario'],
			"password" => $_POST['password']
		];
		$consultaSQL = "INSERT INTO login (usuario,password)"; // insertar datos en tabla login 
		$consultaSQL .= "values (:".implode(", :", array_keys($user)).")";
		$sentencia = $conexion->prepare($consultaSQL);
		$sentencia->execute($user);
        header("location: session.php");
	} catch(PDOException $error){
		$resultado['error']=true;
		$resultado['mensaje']=$error->getMessage();
	}
}
?>

<?php include "templates/header.php"; ?>
<?php  
if (isset($resultado)){
	?>
	<div class="container">
 	 <div class="row">
  	  <div class="col-md-12">
  	   <div class="alert alert-<?= $resultado['error'] ? ' danger' : 'success' ?> " role="alert">
  	   		<?= $resultado['mensaje'] ?>
  	   	</div>
  	   </div>
  	</div>
  </div>
  <?php
}
?>

<div class="container"><!--input de los usuarios creados-->
 <div class="row">
  <div class="col-md-12">
  	<h2 class="mt-4">Crear Usuario</h2>
  	<hr>
  	<form method="post">
  	 <div class="form-group">
  	  <label for="usuario">Usuario</label>
  	  <input type="text" name="usuario" id="usuario" class="form-control">
  	 </div>
  	 <div class="form-group">
  	  <label for="apellido">Contraseña</label>
  	  <input type="password" name="password" id="password" class="form-control">
  	 </div>
  	 <div class="form-group">
  	  <input type="submit" name="submit" class="btn btn-primary" value="Enviar">
		<br><br>
  	  <a class="btn btn-primary" href="session.php">Cancelar</a>
  	 </div>
  	</form>
  </div>
</div>
</div>
<?php include "templates/footer.php"; ?>