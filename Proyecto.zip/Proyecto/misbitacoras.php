<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis bitacoras</title>
    <link rel="icon" href="favicon/bitacora.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/tabla.css">
</head>
<body>
    <?php
    session_start();
    $config = include 'config.php';
    $mail = $_SESSION['Usuarios']['mail'];
    $nombre = $_SESSION['Usuarios']['user'] .' '. $_SESSION['Usuarios']['apellido'];

	try {
		$dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'];
		$conexion = new PDO($dsn,$config['db']['user'],$config['db']['pass'],$config['db']['option']);
		$consultaSQL = "SELECT * FROM archivos WHERE mail='$mail'";
		$array = $conexion->prepare($consultaSQL);
		$array->execute();?>
        <br>
        
        <h1 class= "Titulo">Bitacoras de <?php echo $_SESSION['Usuarios']['user'] , $_SESSION['Usuarios'] ['apellido'] ?></h1>
        <h1 class= "Titulo">Correo institucional <?php echo $_SESSION['Usuarios']['mail']?></h1>      
        <table>
        <div class="container">
            <div class="table">
            <tr>
                <th>Id</th>
                <th>nombre</th>
                <th>fecha</th>
                <th>Archivo</th>
            </tr>
            </div>
        </div>
        <?php
        $cont = 1;
        foreach ($array as $rd){
            ?>
            <div class="container">
                <div class = 'table'>
                    <tr>
                        <td><?php echo $cont; ?></td>
                        <td><?php echo $rd['nombre'] ?></td>
                        <td><?php echo $rd['fecha'] ?></td>
                        <td><a href="<?php echo $rd['ruta'] ?>">Descargar</a></td>
                    </tr>
                </div>
            </div>
            
        <?php
        $cont += 1 ; 
        } ?>
        </table>
        <form method="post">
            <br>
            <button type="submit" class="button-35" role="button"name="informe">Generar Reporte</button>
            <br>
            <br>    
            <button type="button" class="button-35" style="width:185px;" target="_blank" onclick="location.href='alumno.php'" >Volver atras</button>
        </form>
        
    <?php
    if (isset($_POST['informe'])){
        $dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'];
		$conexion = new PDO($dsn,$config['db']['user'],$config['db']['pass'],$config['db']['option']);
		$consultaSQL = "SELECT * FROM archivos WHERE mail='$mail'";
		$array = $conexion->prepare($consultaSQL);
		$array->execute();



        require('fpdf/fpdf.php');
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(0,10,'Reporte bitacoras practica',0,1,'C');
        $pdf->SetFont('Arial','',12);
        $pdf->Cell(0,10,'Nombre del alumno: '.$nombre,0,1,'C');
        $pdf->Cell(0,10,'Correo institucional: '.$mail,0,1,'C');
        $cont = 1;
        foreach ($array as $rd){
            $Leerinforme = fopen("upload/".$rd['mail']."/".$rd['fecha']."/bitacora.txt" , "rb");
            $datos = fread($Leerinforme,filesize("upload/".$rd['mail']."/".$rd['fecha']."/bitacora.txt"));
            $pdf->Cell(0,10,utf8_decode('Fecha '.$rd['fecha']),0,1,'C');
            $pdf->Cell(0,10,utf8_decode('Bitacora N° '.$cont),0,1,'C');
            $pdf->Cell(0,10,$datos,0,1,'C');
            $cont += 1;
        }
        $route = "upload/".$rd['mail']."/";
        $pdf->Output($route.'file.pdf', 'f');

        header('location:'.$route.'file.pdf');
    /*  exporta un archivo TXT:
        $informe = fopen("upload/".$mail."/InformeGenerado.txt", "w");
        foreach($array as $rd){
            $Leerinforme = fopen("upload/".$rd['mail']."/".$rd['fecha']."/bitacora.txt" , "rb");
            $datos = fread($Leerinforme,filesize("upload/".$rd['mail']."/".$rd['fecha']."/bitacora.txt"));
            fwrite($informe, "informe de ".$_SESSION['Usuarios']['user']."\n\n".$rd['fecha']. "\n". $datos ."\n\n");  
        }
        fclose($informe); */
    }
    
	} catch(PDOException $error){
		$resultado['error']=true;
		$resultado['mensaje']=$error->getMessage();
	}
    ?>
</body>
</html>