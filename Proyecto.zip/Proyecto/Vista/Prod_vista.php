<?php include 'funciones.php'?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <link rel="stylesheet" href="css/tabla.css">

    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>inicio de sesión🔒</title>
    <style>
        body{
            background-image:url(../IMG/aa.jpg);
        }
        td {
            text-align: center;
        }
    </style>
</head>
<body>
    <?php
    session_start();
    if (isset($_SESSION['Usuarios']['mail'])){ //bienvenida al usuario logueado
        $usuario = $_SESSION['Usuarios']['user'];
        echo "<h2>Bienvenido: $usuario</h2>";
        $rol = $_SESSION['Usuarios']['rol'];
        if ($rol == '1'){
            $rolito = 'Administrador';
            echo "<h2>Su rol es: $rolito </h2>";
        }
        if ($rol == '2'){
            header('location: alumno.php');
        }
        if ($rol == '3'){
            header('location: ...'); #Redirigir a la pagina del rol
        }
        if ($rol == '4'){
            header('location: ...'); #Redirigir a la pagina del rol
        }
    }else{
        header('location: session.php');
    }
    if (isset($_POST['cerrar'])){ //Cerrar sesión
        session_destroy();
        header('location: session.php');
    }
    if (isset($_POST['agregar'])){//Crear nuevo usuario para loguear
        header('location: crear.php');
    }
    ?>
<br></br>
<div class="container-fluid my-class">
    <div class="container">
    <h1 class="Titulo_usu">Usuarios Ingresados</h1>
    <form method="POST">
    <input type="submit" value="Agregar Usuario" name="agregar" href="crear.php"><!--Agregar usuario a la bdd de los alumnos  -->
    <br><br>
    <input type="submit" name="cerrar" value="Cerrar sesión"><!--  Cerrar la sesion actual -->
</form>
    </div>
</div>


<div id="tablita"> <!-- div de tabla -->
    <table>
        <br><br>
        <thead>   
             <!--atributos -->
        <tr><th>Nombre<br></th> 
        <th>Apellido</th>
        <th>Rut</th>
        <th>Telefono</th>
        <th>Edad</th>
        <th>Mail</th>
        <th>Numero de emergencia</th>
        <th>ROL</th>
        <th>Contraseña</th> <!-- Esto se lo quitaria -->
        <th>-</th>
        <th>-</th>
        </tr>
        </thead>   
    <?php 
        foreach($matrizProductos as $registro){  ?>  <!-- consulta de datos segun su parametro -->
        <tr>
            
        <?php echo "<td>". $registro["nombre"]. "</td>";
        echo "<td>". $registro["apellido"]. "</td>";
        echo "<td>". $registro["rut"]. "</td>";
        echo "<td>". $registro["telefono"]. "</td>";
        echo "<td>". $registro["edad"]. "</td>";
        echo "<td>". $registro["mail"]. "</td>";
        echo "<td>". $registro["n_emergencia"]. "</td>";
        echo "<td>". $registro["rol"]. "</td>";
        echo "<td>". $registro["password"]. "</td>"; ?> <!-- Esto lo quitaria --> 
        <td><a href="<?= 'editar.php?id='.escapar($registro["id"]) ?>">✏️ Editar</a></td>
        <td><a href="<?= 'borrar.php?id='.escapar($registro["id"]) ?>">🗑️ Borrar</a></td>
        </tr>
        <?php
        }
    
    ?>
    </table>
    </div>
</body>
</html>