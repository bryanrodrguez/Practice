
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/cerrar.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Alumno</title>
</head>
<form method="POST">
    <div class="cerrar_session">
        <input type="submit" name="cerrar" value="Cerrar sesión" >
    </div>
</form>
<body>
    <div>

    </div>
    <?php
    session_start();
    if (isset($_SESSION['Usuarios']['mail'])){ //bienvenida al usuario logueado
        if (isset($_POST['cerrar'])){ //Cerrar sesión
            session_destroy();
            header('location: session.php');
        }

        $usuario = $_SESSION['Usuarios']['user'];
        echo "<h2>Bienvenido: $usuario </h2> ";
        $rol = $_SESSION['Usuarios']['rol'];
        if ($rol == '1'){
            echo "<h2>Su rol es: $rol (Administrador)</h2>";
        }
        if ($rol == '2'){
            echo "<h2>Su rol es: $rol (Alumno)</h2>";
        }
       
    }else{
        header('location: session.php');
    }
    if (isset($_POST['cerrar'])){ //Cerrar sesión
        session_destroy();
        header('location: session.php');
    }
    ?>
    <br><br>
    <div class="Titulo">
        <div class="titulo_contenido">
            <div class="texto">
                <label>
                <p>Ingrese su bitacora para el dia: 
                <input type="date" name="trip-start"
                value="2022-01-01"
                min="2015-01-01" max="2023-12-31"></label></p>
            </div>
            
        </div>
    </div>

    <br>
    <input type="text" id="name" class="someclass">
    <div>
    <div class="hola">asdasd</div>
    <div class="hola2">asdasd</div>
    </div>
    
</body>



</html>