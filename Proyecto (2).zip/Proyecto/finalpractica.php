<?php
session_start();

require 'conexion.php';
$config = include 'config.php';


$usuario = $_SESSION['Usuarios']['mail'];
$query = "SELECT EXISTS (SELECT * from status where mail= '$usuario')";
$consulta = mysqli_query($conexion, $query);
$array = mysqli_fetch_array($consulta);

if ($array[0] == 0){
    $dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'];
    $conexion = new PDO($dsn,$config['db']['user'],$config['db']['pass'],$config['db']['option']);

    $usuario = $_SESSION['Usuarios']['user'] . ' ' . $_SESSION['Usuarios']['apellido'];
    $rut = $_SESSION['Usuarios']['rut'];
    $mail = $_SESSION['Usuarios']['mail'];
    $estado = '-';
    $calificacionJC = '-';
    $calificacionDC = '-';
    $calificacionCompleta = '-';
    $Observaciones = '-';
    $usuario = [  //variable usuario junto a sus atributos
        "NombreUsuario" => $usuario,
        "Rut" => $rut,
        "Mail" => $mail,
        "Estado" => $estado,
        "Calificacion_JC" => $calificacionJC,
        "Calificacion_DC" => $calificacionDC,
        "CalificacionCompleta" => $calificacionCompleta,
        "Observacion" => $Observaciones
    ];
    $query = "INSERT INTO status (NombreUsuario,Rut,Mail,Estado,Calificacion_JC,Calificacion_DC,CalificacionCompleta,Observacion)";
    $query .= "values (:".implode(", :", array_keys($usuario)).")";
    $sentencia = $conexion->prepare($query);
    $sentencia->execute($usuario);
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis bitacoras</title>
    <link rel="icon" href="favicon/bitacora.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <!--- <link rel="stylesheet" href="./css/tabla.css"> -->
    <script src="http://code.jquery.com/jquery-latest.js"></script>
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <?php
        
        $usuario = $_SESSION['Usuarios']['mail'];
        $query = "SELECT * from status where mail= '$usuario'";
        $consulta = mysqli_query($conexion, $query);
        $array = mysqli_fetch_array($consulta);
        
        $usuario = $array['NombreUsuario'];
        $rut = $array['Rut'];
        $mail = $array['Mail'];
        $estado = $array['Estado'];
        $calificacionJC = $array['Calificacion_JC'];
        $calificacionDC = $array['Calificacion_DC'];
        $calificacionCompleta = $array['CalificacionCompleta'];
        $Observaciones = $array['Observacion'];

        if (isset($_POST['enviar'])){
            if(is_uploaded_file($_FILES['fichero']['tmp_name'])){
                if(file_exists("upload/".$mail."/Informe_Completo") == false){
                    mkdir("upload/".$mail."/Informe_Completo");
                
                }else{
                    $flag = true;                    
                }  
                

    }
}
        ?>
        <style>         
        table, tr, th, td{
            border: 1px solid;
            text-align: center;
            width: 1300px;
        }
        </style>
        <table id="feedback-bg-info">
            <tr>
                <th>Alumno</th>
                <th>Rut</th>
                <th>Mail</th>
                <th>Estado</th>
                <th>Calificacion Jefe Carrera</th>
                <th>Calificacion Docente Supervisor</th>
                <th>Calificacion Completa</th>
                <th>Obeservaciones</th>
            </tr>
            <td><?php echo $usuario; ?></td>
            <td><?php echo $rut; ?></td>
            <td><?php echo $mail; ?></td>
            <td><?php echo $estado; ?></td>
            <td><?php echo $calificacionJC; ?></td>
            <td><?php echo $calificacionDC; ?></td>
            <td><?php echo $calificacionCompleta; ?></td>
            <td><?php echo $Observaciones; ?></td>
        </table>
        <br>
        <input name="fichero" type="file" class="button-35"><br><br>
        <button name="enviar" onclick="sb()" class="button-35">Enviar</button>
    </form>
        
        <script>
            $(document).ready(function() {
            var refreshId =  setInterval( function(){
                $('#feedback-bg-info').load('prueba.php');//actualizas el div
            }, 2500 );
            });
        </script>
    </form>


    
</body>
</html>