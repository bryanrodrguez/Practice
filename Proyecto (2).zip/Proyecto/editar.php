<?php  
include 'funciones.php';

$config = include 'config.php';
$resultado = [
	'error'=>false,
	'mensaje'=>''
];

if (!isset($_GET['id'])){
	$resultado['error'] =true;
	$resultado['mensaje'] ='El usuario no existe';
}

if (isset($_POST['submit'])){
	$resultado =[
		'error' =>false,
		'mensaje'=>'El usuario '.$_POST['nombre'].' ha sido modificado con éxito'//editar datos del alumno creado
	];
	try {
		$dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'];
		$conexion = new PDO($dsn,$config['db']['user'],$config['db']['pass'],$config['db']['option']);
		$usuario= [//atributos de variable alumno
			"id" => $_GET['id'],
			"nombre" => $_POST['nombre'],
			"apellido" => $_POST['apellido'],
			"rut" => $_POST['rut'],
			"telefono" => $_POST['telefono'],
			"edad" => $_POST['edad'],
			"mail" => $_POST['mail'],
			"n_emergencia" => $_POST['n_emegencia'],
			"rol" => $_POST['rol'],
			"password" => $_POST['password'],
		];
		$consultaSQL = "UPDATE log SET 
			nombre = :nombre,
			apellido = :apellido,
			rut = :rut,
			telefono = :telefono,
			edad = :edad,
			mail = :mail,
			n_emergencia = :n_emergencia,
			rol = :rol,
			password = :password
			updated_at = NOW()
			WHERE id = :id";//updatear datos de alumnos
		$sentencia = $conexion->prepare($consultaSQL);
		$sentencia->execute($usuario);
	} catch(PDOException $error){
		$resultado['error']=true;//mensaje de error o aprobacion
		$resultado['mensaje']=$error->getMessage();
	}
}

try {
	$dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'];
	$conexion = new PDO($dsn,$config['db']['user'],$config['db']['pass'],$config['db']['option']);
	$id = $_GET['id'];
	$consultaSQL = "SELECT * FROM log WHERE id=".$id; //muestra de datos de los alumnos
	$sentencia = $conexion->prepare($consultaSQL);
	$sentencia->execute();
	$usuario =$sentencia->fetch(PDO::FETCH_ASSOC);
	if(!$usuario){
		$resultado['error'] =true;
		$resultado['mensaje'] ='El alumno no se ha encontrado';
	}
}catch(PDOException $error){
		$resultado['error']=true;
		$resultado['mensaje']=$error->getMessage();
	}
?>

<?php require "templates/header.php"; ?>
<?php
if ($resultado['error']) {
  ?>
  <div class="container mt-2">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-danger" role="alert">
          <?= $resultado['mensaje'] ?>
        </div>
      </div>
    </div>
  </div>
  <?php
}
if (isset($resultado)){
	?>
	<div class="container">
 	 <div class="row">
  	  <div class="col-md-12">
  	   <div class="alert alert-<?= $resultado['error'] ? ' danger' : 'success' ?> " role="alert">
  	   		<?= $resultado['mensaje'] ?>
  	   	</div>
  	   </div>
  	</div>
  </div>
  <?php
}
?>

<?php
if (isset($usuario) && $usuario) {
  ?>
    <div class="container">
     <div class="row">
      <div class="col-md-12"><!--inputs de datos del alumno-->
      	<h2 class="mt-4">Editando el usuario <?= escapar($usuario['nombre']) . ' ' . escapar($usuario['apellido'])  ?></h2>
        <hr>
        <form method="post">
          <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre" value="<?= escapar($usuario['nombre']) ?>" class="form-control">
          </div>

          <div class="form-group">
            <label for="apellido">Apellido</label>
            <input type="text" name="apellido" id="apellido" value="<?= escapar($usuario['apellido']) ?>" class="form-control">
          </div>
          <div class="form-group">
            <label for="rut">Rut</label>
            <input type="rut" name="rut" id="rut" value="<?= escapar($usuario['rut']) ?>" class="form-control">
          </div>
          <div class="form-group">
  	  <label for="telefono">telefono</label>
  	  <input type="text" name="telefono" id="telefono" value ="<?=escapar($usuario['telefono']) ?>" class="form-control">
  	 </div>
  	 <div class="form-group">
  	  <label for="edad">edad</label>
  	  <input type="text" name="edad" id="edad" value ="<?=escapar($usuario['edad']) ?>" class="form-control">
  	 </div>
  	 <div class="form-group">
  	  <label for="mail">Mail</label>
  	  <input type="text" name="mail" id="mail" value ="<?=escapar($usuario['mail']) ?>" class="form-control">
  	 </div>
  	 <div class="form-group">
  	  <label for="password">Contraseña</label>
  	  <input type="text" name="password" id="password" value ="<?=escapar($usuario['password']) ?>" class="form-control">
  	 </div>
  	 <div class="form-group">
  	  <label for="n_emergencia">Numero de emergencia</label>
  	  <input type="text" name="n_emergencia" id="n_emergencia" value ="<?=escapar($usuario['n_emergencia']) ?>" class="form-control">
  	 </div>
	<label>Rol de usuario </label>
	<br>
	<div class="input-group mb-3">
	
	
  	<select class="custom-select" id="inputGroupSelect02" name ="rol">
	  	<label for="rol">Rol de usuario </label>
    	<option selected>Elige...</option>
    	<option name="rol" id="rol" value="1">ADMINISTRADOR</option>
    	<option name="rol" id="rol" value="2">ALUMNO</option>
    	<option name="rol" id="rol" value="3">TUTOR</option>
    	<option name="rol" id="rol" value="4">JEFE DE CARRERA</option>
  	</select>
	</div>
</div>


      </form>
  </div>
</div>
</div>
<?php
}
?>
<?php require "templates/footer.php"; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar</title>
    <link rel="stylesheet" href="css/login.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>

<!--Scripts de boostrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

</body>
</html>