
<?php

require 'conexion.php';
session_start();

$usuario = $_SESSION['Usuarios']['mail'];
$query = "SELECT * from status where mail= '$usuario'";
$consulta = mysqli_query($conexion, $query);
$array = mysqli_fetch_array($consulta);
?>

<?php 
        
        $usuario = $array['NombreUsuario'];
        $rut = $array['Rut'];
        $mail = $array['Mail'];
        $estado = $array['Estado'];
        $calificacionJC = $array['Calificacion_JC'];
        $calificacionDC = $array['Calificacion_DC'];
        $calificacionCompleta = $array['CalificacionCompleta'];
        $Observaciones = $array['Observacion'];
        ?>
        <style>         
        table, tr, th, td{
            border: 1px solid;
            text-align: center;
            width: 1300px;
        }
        </style>
        <table>
            <tr>
                <th>Alumno</th>
                <th>Rut</th>
                <th>Mail</th>
                <th>Estado</th>
                <th>Calificacion Jefe Carrera</th>
                <th>Calificacion Docente Supervisor</th>
                <th>Calificacion Completa</th>
                <th>Obeservaciones</th>
            </tr>
            <td><?php echo $usuario; ?></td>
            <td><?php echo $rut; ?></td>
            <td><?php echo $mail; ?></td>
            <td><?php echo $estado; ?></td>
            <td><?php echo $calificacionJC; ?></td>
            <td><?php echo $calificacionDC; ?></td>
            <td><?php echo $calificacionCompleta; ?></td>
            <td><?php echo $Observaciones; ?></td>
        </table>


